    const v0, 0x7f0aID2 #id/news1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    
    #activity version:
    
    #invoke-virtual {p0, v0}, Lcom/package/name/YourActivity;->findViewById(I)Landroid/view/View;
    
    #difference: p1 is rootView from onCreateView, p0 is activity

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.widget.ImageView"

    invoke-static {v0, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    move-object v6, v0

    new-instance v1, Lcom/package/name/News$3;

    invoke-direct {v1, p0}, Lcom/package/name/News$3;-><init>(Lcom/package/name/YourFragment;)V

    invoke-virtual {v6, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f0aID2 #id/news2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-string v1, "null cannot be cast to non-null type android.widget.ImageView"

    invoke-static {v0, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    move-object v7, v0

    new-instance v1, Lcom/package/name/YourFragment$4;

    invoke-direct {v1, p0}, Lcom/package/name/YourFragment$4;-><init>(Lcom/package/name/YourFragment;)V

    invoke-virtual {v7, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v8, Ljava/lang/Thread;

    new-instance v9, Lcom/package/name/News$ImageLoader;

    const-string v10, "https://raw.githubusercontent.com/username/repository/main/news1.webp"

    invoke-direct {v9, v10, v6}, Lcom/package/name/News$ImageLoader;-><init>(Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-direct {v8, v9}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v8}, Ljava/lang/Thread;->start()V

    new-instance v8, Ljava/lang/Thread;

    new-instance v9, Lcom/package/name/News$ImageLoader;

    const-string v10, "https://raw.githubusercontent.com/username/repository/main/news2.webp"

    invoke-direct {v9, v10, v7}, Lcom/package/name/News$ImageLoader;-><init>(Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-direct {v8, v9}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v8}, Ljava/lang/Thread;->start()V