# classes.dex

.class Lcom/package/name/News$ImageLoader;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private imageView:Landroid/widget/ImageView;

.field private url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/widget/ImageView;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/package/name/News$ImageLoader;->url:Ljava/lang/String;

    iput-object p2, p0, Lcom/package/name/News$ImageLoader;->imageView:Landroid/widget/ImageView;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 7

    :try_start_0
    new-instance v0, Ljava/net/URL;

    iget-object v1, p0, Lcom/package/name/News$ImageLoader;->url:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v2

    iget-object v3, p0, Lcom/package/name/News$ImageLoader;->imageView:Landroid/widget/ImageView;

    new-instance v4, Lcom/package/name/News$ImageLoader$SetBitmapRunnable;

    invoke-direct {v4, v3, v2}, Lcom/package/name/News$ImageLoader$SetBitmapRunnable;-><init>(Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->post(Ljava/lang/Runnable;)Z
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_19} :catch_1a

    return-void

    :catch_1a
    move-exception v0

    return-void
.end method
