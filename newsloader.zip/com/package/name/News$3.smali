.class public Lcom/package/name/News$3;
.super Ljava/lang/Object;
.source "YourFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/package/name/YourFragment;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Lcom/package/name/YourFragment;


# direct methods
.method public constructor <init>(Lcom/package/name/YourFragment;)V
    .registers 2

    iput-object p1, p0, Lcom/package/name/News$3;->this$0:Lcom/package/name/YourFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    .line 1
    new-instance p1, Landroid/content/Intent;

    const-string v0, "https://username.github.io/repository/1"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {p1, v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    iget-object v0, p0, Lcom/package/name/News$3;->this$0:Lcom/package/name/YourFragment;

    invoke-virtual {v0, p1}, Lcom/package/name/YourFragment;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
